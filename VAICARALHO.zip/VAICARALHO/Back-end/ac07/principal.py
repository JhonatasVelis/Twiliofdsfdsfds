from infra.to_dict import to_dict, to_dict_list
from flask import Flask, jsonify, request
from pedido import pedidos_app
from infra.db import criar_db

app = Flask(__name__)
app.register_blueprint(pedidos_app)

@app.route('/') 
def all():

    from services.pedido_service import listar as listar
    database = {
    "PEDIDOS" : to_dict_list(listar())
    }
    return jsonify(database)
    

criar_db()

if __name__ == '__main__':
    app.run(host='localhost', port=5000, debug = True)
