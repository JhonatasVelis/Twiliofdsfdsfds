from flask import Blueprint, jsonify, request
from twilio.rest import Client
from infra.validacao import validar_campos
from infra.to_dict import to_dict, to_dict_list
from services.pedido_service import \
    listar as service_listar, \
    localizar as service_localizar, \
    criar as service_criar, \
    remover as service_remover, \
    atualizar as service_atualizar, \
    AlunoJaExiste

pedidos_app = Blueprint('pedidos_app',  __name__)

campos = ["id", "nome"]
tipos = [int, str]

@pedidos_app.route('/pedido', methods=['GET'])
def listar():
    lista = service_listar()
    return jsonify(to_dict_list(lista))

@pedidos_app.route('/pedido/<int:id>', methods=['GET'])
def localizar(id):
    x = service_localizar(id)
    if x != None:
        return jsonify(to_dict(x))
    return '', 404

@pedidos_app.route('/pedido',methods=['POST'])
def criar():
    dados = request.get_json()
    try:
        criado = service_criar(dados['nome'], dados['cpf'],dados['cep'],dados['rua'],dados['bairro'],dados['numero'],dados['email'],dados['telefone'],dados['saborpizza'],dados['quantidadePizza'],dados['formaPagamento'],dados['valorTotal'])
        account_sid = 'AC4e39b673bca6db8b55d0d29b11cfb74a'
        auth_token = '117b13ed63ebb7e805a51a5f7b676aa1'
        client = Client(account_sid, auth_token)

        message = client.messages \
                        .create(
                            body="Parabéns! " + dados['nome'] + " Seu pedido foi realizado com sucesso!",
                            from_='+18134135845',
                            to= dados['telefone']
                        )
        return jsonify(to_dict(criado))
    except AlunoJaExiste:
        return '', 409


@pedidos_app.route('/pedido/<int:id>', methods=['DELETE'])
def remover(id):
    removido = service_remover(id)
    if removido != None:
        return "O pedido " + str(id) + " foi excluído com sucesso!"
    return '', 404


@pedidos_app.route('/pedido/<int:id>', methods=['PUT'])
def atualizar(id):
    atualizado = service_atualizar(id,)
    if atualizado != None:
        return "O pedido " + str(id) + " foi concluído com sucesso!"
    return '', 404

    