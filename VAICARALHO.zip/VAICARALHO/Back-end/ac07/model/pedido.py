class Pedido():
    def __init__(self, nome,cpf,cep,rua,bairro,numero,email,telefone,saborpizza,quantidadePizza,formaPagamento,valorTotal,statusPedido = None,numeroPedido = None):
        self.__nome = nome
        self.__cpf = cpf
        self.__cep = cep
        self.__rua = rua
        self.__bairro = bairro
        self.__numero = numero
        self.__email = email
        self.__telefone = telefone
        self.__saborpizza = saborpizza
        self.__quantidadePizza = quantidadePizza
        self.__formaPagamento = formaPagamento
        self.__valorTotal = valorTotal
        self.__statusPedido = statusPedido
        self.__numeroPedido = numeroPedido
        
    
    @property
    def nome(self):
        return self.__nome

    @property
    def cpf(self):
        return self.__cpf

    @property
    def cep(self):
        return self.__cep

    @property
    def rua(self):
        return self.__rua

    @property
    def bairro(self):
        return self.__bairro

    @property
    def numero(self):
        return self.__numero

    @property
    def email(self):
        return self.__email

    @property
    def telefone(self):
        return self.__telefone

    @property
    def saborpizza(self):
        return self.__saborpizza

    @property
    def quantidadePizza(self):
        return self.__quantidadePizza

    @property
    def formaPagamento(self):
        return self.__formaPagamento

    @property
    def valorTotal(self):
        return self.__valorTotal

    @property
    def statusPedido(self):
        return self.__statusPedido

    @property
    def numeroPedido(self):
        return self.__numeroPedido