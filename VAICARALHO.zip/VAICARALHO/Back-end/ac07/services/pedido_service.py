from model.pedido import Pedido
from infra.log import Log

from dao.pedido_dao import \
    listar as listar_dao, \
    localizar as localizar_dao, \
    criar as criar_dao, \
    remover as remover_dao, \
    atualizar as atualizar_dao

class AlunoJaExiste(Exception):
    pass

def listar():
    return listar_dao()

def localizar(id):
    return localizar_dao(id)

def criar(nome,cpf,cep,rua,bairro,numero,email,telefone,saborpizza,quantidadePizza,formaPagamento,valorTotal):
    criado = Pedido(nome,cpf,cep,rua,bairro,numero,email,telefone,saborpizza,quantidadePizza,formaPagamento,valorTotal)
    criar_dao(criado)
    return criado

def remover(id):
    existente = localizar(id)
    log = Log(existente)
    remover_dao(id)
    log.finalizar(None)
    return existente

def atualizar(id):
    existente = localizar(id)
    if existente == None:
        return None
    atualizar_dao(id)
    return existente

