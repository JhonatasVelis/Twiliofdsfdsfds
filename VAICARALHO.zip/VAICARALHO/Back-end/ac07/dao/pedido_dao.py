from infra.db import con
from wrap_connection import transact 
from model.pedido import Pedido

sql_criar = "INSERT INTO PEDIDO(nome,cpf, CEP,RUA,BAIRRO,NUMERO,EMAIL,TELEFONE,SABORPIZZA,QUANTIDADE_PIZZA,FORMA_PAGAMENTO,VALOR_TOTAL) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)"
sql_listar = "SELECT * FROM PEDIDO"
sql_localizar = "SELECT * FROM PEDIDO WHERE id = ?"
sql_delete  = "DELETE FROM PEDIDO WHERE id = ?"
sql_atualizar = "UPDATE PEDIDO SET STATUS_PEDIDO = 2 WHERE id = ?"

alunos_db = []

class AlunoJaExiste(Exception):
    pass

@transact(con)
def listar():
    cursor.execute(sql_listar)
    resultado = []
    for r in cursor.fetchall():
        resultado.append(Pedido(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8],r[9],r[10],r[11],r[12],r[13]))
    return resultado

@transact(con)
def localizar(id):
    cursor.execute(sql_localizar, (id,))
    r = cursor.fetchone()
    if r == None:
        return None
    return Pedido(r[0],r[1],r[2],r[3],r[4],r[5],r[6],r[7],r[8],r[9],r[10],r[11])

@transact(con)
def criar(pedido):
    cursor.execute(sql_criar, (pedido.nome,pedido.cpf,pedido.cep, pedido.rua,pedido.bairro,pedido.numero,pedido.email,pedido.telefone,pedido.saborpizza,pedido.quantidadePizza,pedido.formaPagamento,pedido.valorTotal))
    connection.commit()

@transact(con)
def remover(id):
    cursor.execute(sql_delete, (id,))
    connection.commit()

@transact(con)
def atualizar(id):
    cursor.execute(sql_atualizar, (id,))
    connection.commit()


